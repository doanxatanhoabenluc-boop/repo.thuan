/* Copyright (c) 2007 Google Inc.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

// 
// GDataPhotos.h
//

#import "GDataElements.h"

// Google Photos/Picasa Web
#import "GDataPhotoElements.h"
#import "GDataEXIFTags.h"
#import "GDataEntryPhotoBase.h"
#import "GDataEntryPhoto.h"
#import "GDataEntryPhotoAlbum.h"
#import "GDataEntryPhotoComment.h"
#import "GDataEntryPhotoTag.h"
#import "GDataEntryPhotoUser.h"
#import "GDataFeedPhotoBase.h"
#import "GDataFeedPhoto.h"
#import "GDataFeedPhotoAlbum.h"
#import "GDataFeedPhotoUser.h"
#import "GDataServiceGooglePicasaWeb.h"
#import "GDataQueryPicasaWeb.h"
