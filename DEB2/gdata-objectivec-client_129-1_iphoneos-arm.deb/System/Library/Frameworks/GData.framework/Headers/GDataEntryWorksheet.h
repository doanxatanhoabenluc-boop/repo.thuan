/* Copyright (c) 2007 Google Inc.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

//
//  GDataEntryWorksheet.h
//

#import "GDataEntryBase.h"


#undef _EXTERN
#undef _INITIALIZE_AS
#ifdef GDATAENTRYWORKSHEET_DEFINE_GLOBALS
#define _EXTERN 
#define _INITIALIZE_AS(x) =x
#else
#define _EXTERN extern
#define _INITIALIZE_AS(x)
#endif

_EXTERN NSString* kGDataCategoryWorksheet _INITIALIZE_AS(@"http://schemas.google.com/spreadsheets/2006#worksheet");

// WorksheetEntry extensions

@interface GDataEntryWorksheet : GDataEntryBase {
}

+ (GDataEntryWorksheet *)worksheetEntry;

// Hard upper bound of rows and columns, perhaps including
// empty rows and columns.
- (int)rowCount;
- (void)setRowCount:(int)val;

- (int)columnCount;
- (void)setColumnCount:(int)val;  
@end

